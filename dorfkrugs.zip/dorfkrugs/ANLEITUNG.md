# Die Dorfkrugs – Einrichtung (ca. 15 Minuten)

Du hast drei Dateien:
- `index.html` – die Abstimmungsseite
- `logo.jpg` – dein Logo
- `apps-script.gs` – das Backend, das die Stimmen in dein Google Sheet schreibt (nur du siehst sie)

---

## 1. Google Sheet + Backend einrichten

1. Leg auf https://sheets.new ein neues Google Sheet an, z. B. „Dorfkrugs 2026 Stimmen“.
2. Klick im Menü auf **Erweiterungen → Apps Script**.
3. Lösch den vorhandenen Code, füg den kompletten Inhalt von `apps-script.gs` ein und speichere (💾).
4. Klick oben rechts auf **Bereitstellen → Neue Bereitstellung**.
   - Zahnrad bei „Typ auswählen“ → **Web-App**
   - Ausführen als: **Ich**
   - Zugriff: **Jeder**
   - → **Bereitstellen**
5. Google will eine Berechtigung → **Zugriff autorisieren** → dein Konto wählen.
   Wenn „Google hat diese App nicht überprüft“ kommt: **Erweitert → Zu … wechseln (unsicher)**. Das ist normal, es ist ja dein eigenes Skript.
6. Kopier die **Web-App-URL** (endet auf `/exec`).
   Test: Öffnest du sie im Browser, sollte „Dorfkrugs-Backend läuft ✔“ erscheinen.

## 2. URL in die Seite eintragen

Öffne `index.html` in einem Texteditor und such ganz unten im Script:

```js
ENDPOINT: "",
```

Füg dort deine URL zwischen die Anführungszeichen ein:

```js
ENDPOINT: "https://script.google.com/macros/s/……/exec",
```

Speichern. Der gelbe „Testmodus“-Balken verschwindet dann.

## 3. Auf GitHub Pages hochladen

1. Leg auf https://github.com/new ein neues Repository an, z. B. `dorfkrugs`, und stell es auf **Public**.
2. Klick auf **Add file → Upload files**, zieh `index.html` und `logo.jpg` rein und klick auf **Commit changes**.
   `apps-script.gs` und diese Anleitung musst du nicht hochladen.
3. Geh auf **Settings → Pages** und stell bei „Branch“ **main** und **/ (root)** ein → **Save**.
4. Nach 1–2 Minuten ist die Seite online unter
   `https://DEIN-GITHUB-NAME.github.io/dorfkrugs/`

Die Twitch-Clips werden automatisch richtig eingebettet, da musst du nichts einstellen.
Die Stimmen liegen nicht im Repo, sondern nur in deinem Google Sheet. Das Repo darf also öffentlich sein.

## 4. Testen

1. Öffne die Seite in einem **privaten Fenster** und stimm einmal ab.
2. Im Sheet sollte jetzt das Blatt **„Stimmen“** mit deinen Zeilen auftauchen.
3. Lade das Sheet neu. Dann siehst du oben das Menü **🏆 Dorfkrugs → Ergebnisse aktualisieren**.
   Es erstellt eine Rangliste pro Kategorie, die Gewinner sind markiert.
4. Lösch deine Testzeilen im Blatt „Stimmen“ und schick den Link raus. 🥃

---

### Gut zu wissen
- **Nochmal abstimmen zum Testen:** Die Seite merkt sich im Browser, dass man schon abgestimmt hat. Zum Testen also ein privates Fenster benutzen.
- **Clips oder Kategorien ändern:** In `index.html` steht oben im Script die Liste `CATEGORIES`. Dort kannst du Titel und Links einfach anpassen und die Datei auf GitHub neu hochladen.
- **Code im Apps Script geändert?** Dann über **Bereitstellen → Bereitstellungen verwalten → ✏️ → Version: Neue Version** neu bereitstellen. Die URL bleibt dabei gleich.
- **Mehrfach-Voten:** Wer es drauf anlegt, kann über ein anderes Gerät oder ein privates Fenster nochmal abstimmen. Im Sheet siehst du aber Voter-ID und Uhrzeit und kannst auffällige Häufungen löschen, bevor du auf „Ergebnisse aktualisieren“ klickst.
