/**
 * Die Dorfkrugs – Stimmen-Backend
 * In ein Google Sheet einfügen: Erweiterungen → Apps Script → hier alles reinkopieren.
 * Danach als Web-App bereitstellen (siehe ANLEITUNG.md).
 */

const SHEET_VOTES = 'Stimmen';
const SHEET_RESULTS = 'Ergebnisse';

// Nimmt die Stimmen von der Webseite entgegen
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const data = JSON.parse(e.postData.contents);
    const sh = votesSheet_();
    const ts = new Date();
    const voterId = String(data.voterId || '').slice(0, 64);
    const name = String(data.name || '').slice(0, 40);
    const votes = Array.isArray(data.votes) ? data.votes.slice(0, 30) : [];
    const rows = votes.map(v => [ts, voterId, name,
      String(v.category || '').slice(0, 100), String(v.clip || '').slice(0, 150)]);
    if (rows.length) sh.getRange(sh.getLastRow() + 1, 1, rows.length, 5).setValues(rows);
    return ContentService.createTextOutput('ok');
  } finally {
    lock.releaseLock();
  }
}

// Zum Testen: URL im Browser öffnen → "Dorfkrugs-Backend läuft"
function doGet() {
  return ContentService.createTextOutput('Dorfkrugs-Backend läuft ✔');
}

// Menü im Sheet
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('🏆 Dorfkrugs')
    .addItem('Ergebnisse aktualisieren', 'ergebnisse')
    .addToUi();
}

// Zählt die Stimmen und schreibt eine Rangliste pro Kategorie ins Blatt "Ergebnisse"
function ergebnisse() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const data = votesSheet_().getDataRange().getValues().slice(1);

  const counts = {}, order = [], voters = new Set();
  data.forEach(r => {
    const cat = r[3], clip = r[4];
    if (!cat || !clip) return;
    voters.add(r[1]);
    if (!counts[cat]) { counts[cat] = {}; order.push(cat); }
    counts[cat][clip] = (counts[cat][clip] || 0) + 1;
  });

  let out = ss.getSheetByName(SHEET_RESULTS) || ss.insertSheet(SHEET_RESULTS);
  out.clear();
  const rows = [['Kategorie', 'Platz', 'Clip', 'Stimmen', 'Anteil']];
  const winnerRows = [];
  order.forEach(cat => {
    const entries = Object.entries(counts[cat]).sort((a, b) => b[1] - a[1]);
    const total = entries.reduce((s, e) => s + e[1], 0);
    entries.forEach(([clip, n], i) => {
      if (i === 0) winnerRows.push(rows.length + 1);
      rows.push([i === 0 ? cat : '', i + 1, clip, n, n / total]);
    });
    rows.push(['', '', '', '', '']);
  });
  rows.push(['Teilnehmer gesamt', '', '', voters.size, '']);

  out.getRange(1, 1, rows.length, 5).setValues(rows);
  out.getRange(1, 1, 1, 5).setFontWeight('bold').setBackground('#3d120e').setFontColor('#f2b64c');
  out.getRange(2, 5, rows.length, 1).setNumberFormat('0%');
  winnerRows.forEach(r => out.getRange(r, 1, 1, 5).setFontWeight('bold').setBackground('#fbe7c0'));
  out.setFrozenRows(1);
  out.autoResizeColumns(1, 5);
  ss.setActiveSheet(out);
}

function votesSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_VOTES);
  if (!sh) sh = ss.insertSheet(SHEET_VOTES);
  if (sh.getLastRow() === 0) {
    sh.appendRow(['Zeitpunkt', 'Voter-ID', 'Name', 'Kategorie', 'Clip']);
    sh.getRange(1, 1, 1, 5).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}
